import{b as a,d as i}from"./mermaid-parser.core.DXvEiJUb.js";export{a as PieModule,i as createPieServices};
//# sourceMappingURL=pie-BEWT4RHE.E_c7-9Fy.js.map
