import{v as o}from"./2.D7P1Tl2G.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.DXrkzVn9.js.map
