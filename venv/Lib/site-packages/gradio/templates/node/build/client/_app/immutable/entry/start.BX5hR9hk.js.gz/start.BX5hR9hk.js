import{s as t}from"../chunks/client.DrVApSQ4.js";export{t as start};
//# sourceMappingURL=start.BX5hR9hk.js.map
