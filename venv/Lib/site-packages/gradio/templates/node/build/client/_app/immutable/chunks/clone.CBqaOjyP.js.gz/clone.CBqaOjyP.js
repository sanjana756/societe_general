import{b as r}from"./_baseUniq.Cl87irL4.js";var e=4;function a(o){return r(o,e)}export{a as c};
//# sourceMappingURL=clone.CBqaOjyP.js.map
