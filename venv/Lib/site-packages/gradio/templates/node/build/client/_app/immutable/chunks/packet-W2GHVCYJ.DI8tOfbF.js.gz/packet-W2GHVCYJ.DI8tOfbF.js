import{P as c,a as r}from"./mermaid-parser.core.DXvEiJUb.js";export{c as PacketModule,r as createPacketServices};
//# sourceMappingURL=packet-W2GHVCYJ.DI8tOfbF.js.map
