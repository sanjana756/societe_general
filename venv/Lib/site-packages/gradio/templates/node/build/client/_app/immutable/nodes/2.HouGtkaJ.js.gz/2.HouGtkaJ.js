import{Y as e,_ as n}from"../chunks/2.D7P1Tl2G.js";export{e as component,n as universal};
//# sourceMappingURL=2.HouGtkaJ.js.map
