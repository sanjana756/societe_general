import{G as a,f as G}from"./mermaid-parser.core.DXvEiJUb.js";export{a as GitGraphModule,G as createGitGraphServices};
//# sourceMappingURL=gitGraph-YCYPL57B.7yYO53jZ.js.map
